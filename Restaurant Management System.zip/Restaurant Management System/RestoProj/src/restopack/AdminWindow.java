package restopack;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.util.*;
import java.awt.*;
import java.io.*;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.util.Date;

import static restopack.Viewprods.*;

public final class AdminWindow extends javax.swing.JFrame {
  
    public static Statement s;
    public static ResultSet rs;
    public static java.sql.Connection con;
    public static String Viewprods;
    
    DefaultTableModel tblModel = new DefaultTableModel();
    public static String userun=Userreg.userun; //KUHA NAME
    
    public AdminWindow() {
        initComponents();
        getname.setText(Adminreg.name);
        showprodstbl();
        Database();
        foodsss();
    }
    
    public void Database(){
        restopack.Connection c = new restopack.Connection();
        s = restopack.Connection.s;
        con = restopack.Connection.con;
    }
    
     public void foodsss() {
        tblModel = (DefaultTableModel) prodtbl.getModel();
        try {
            s = con.createStatement();
            rs = s.executeQuery("SELECT Id, Name, Price, Add_Date, Image FROM foodstbl");
            ResultSetMetaData md = rs.getMetaData();
            int row = tblModel.getRowCount();
            while (row > 0) {
                row--;
                tblModel.removeRow(row);
            }
            int colcount = md.getColumnCount();
            Object[] data = new Object[colcount];

            while (rs.next()) {
                for (int i = 1; i <= colcount; i++) {
                    data[i - 1] = rs.getString(i);
                }
                    tblModel.addRow(data);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AdminWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
           
    String imgpath=null;
    int pos=0;
    //CHECK INPUT FIELDS
    public boolean checkInputs(){
        if(text_name.getText()==null || text_price.getText()==null  || text_date.getDate()==null){
            return false;
        }
        else{
            try{
                Float.parseFloat(text_price.getText());
                return true;
            }
            catch(Exception ex){
                return false;
            }
        }
    }
    
    //RESIZE IMAGE
    public ImageIcon ResizeImage(String imagepath, byte[]pic){
    ImageIcon myImage=null; 
    
    if(imagepath != null){
        myImage=new ImageIcon(imagepath);
    }
    else{
        myImage=new ImageIcon(pic);
    }
    Image img = myImage.getImage();
    Image img2 = img.getScaledInstance(lblimg.getWidth(), lblimg.getHeight(), Image.SCALE_SMOOTH);
    ImageIcon image=new ImageIcon(img2);
    return image;
}
    //Display Data In Table
    // 1 Fill ArrayList With the Data
  
    public ArrayList<Product> getProductList(){
            ArrayList<Product> productList = new ArrayList<>();
            Database();
            String sel = "SELECT * FROM foodsadmin";
            Statement st;
            
        try {
            st=con.createStatement();
            rs=st.executeQuery(sel);
            Product product;
            
            while(rs.next()){
                product=new Product(rs.getInt("id"),rs.getString("name"),Float.parseFloat(rs.getString("price")),rs.getString("add_date"),rs.getBytes("image"));
                productList.add(product);
            } 
        } 
        catch (SQLException ex) {
            Logger.getLogger(AdminWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        return productList;
    }
   
     //2 Populate the JTable
    public void showprodstbl(){
        ArrayList<Product> list = getProductList();
        DefaultTableModel model = (DefaultTableModel)prodtbl.getModel();
        //to clear jtable content
        model.setRowCount(0);
        Object[] row = new Object[4];
        for(int i=0; i<list.size(); i++){
            row[0]=list.get(i).getid();
            row[1]=list.get(i).getname();
            row[2]=list.get(i).getprice();
            row[3]=list.get(i).getadddate();
             
            model.addRow(row);
        }
    }
    
    public void showItems(int index){
        text_id.setText(Integer.toString(getProductList().get(index).getid()));
        text_name.setText(getProductList().get(index).getname());
        text_price.setText(Float.toString(getProductList().get(index).getprice()));
        
        try {
            Date addDate=null;
            addDate=new SimpleDateFormat("MM-dd-yyyy").parse((String)getProductList().get(index).getadddate());
            text_date.setDate(null);
        } 
        catch (ParseException ex) {
            Logger.getLogger(AdminWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        lblimg.setIcon(ResizeImage(null, getProductList().get(index).getImage()));
    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        text_name = new javax.swing.JTextField();
        text_id = new javax.swing.JTextField();
        text_price = new javax.swing.JTextField();
        firstbtn = new javax.swing.JButton();
        prevbtn = new javax.swing.JButton();
        lastbtn = new javax.swing.JButton();
        nextbtn = new javax.swing.JButton();
        text_date = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        prodtbl = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        imagebtn = new javax.swing.JButton();
        lblimg2 = new javax.swing.JLabel();
        signout = new javax.swing.JButton();
        lblimg3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        signout1 = new javax.swing.JButton();
        lblimg4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        getname = new javax.swing.JLabel();
        lblimg = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        addbtn = new javax.swing.JButton();
        updatebtn = new javax.swing.JButton();
        delbtn = new javax.swing.JButton();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel1.setText("ID:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 230, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel2.setText("NAME:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 280, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel3.setText("PRICE:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 330, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel4.setText("ADD DATE:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 380, -1, -1));
        getContentPane().add(text_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 280, 190, 30));

        text_id.setEnabled(false);
        text_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                text_idActionPerformed(evt);
            }
        });
        getContentPane().add(text_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 230, 70, 30));

        text_price.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                text_priceActionPerformed(evt);
            }
        });
        getContentPane().add(text_price, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 330, 120, 30));

        firstbtn.setText("FIRST");
        firstbtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        firstbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstbtnActionPerformed(evt);
            }
        });
        getContentPane().add(firstbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 650, 80, 30));

        prevbtn.setText("PREV");
        prevbtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        prevbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prevbtnActionPerformed(evt);
            }
        });
        getContentPane().add(prevbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 650, 80, 30));

        lastbtn.setText("LAST");
        lastbtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lastbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lastbtnActionPerformed(evt);
            }
        });
        getContentPane().add(lastbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 650, 80, 30));

        nextbtn.setText("NEXT");
        nextbtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        nextbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextbtnActionPerformed(evt);
            }
        });
        getContentPane().add(nextbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 650, 80, 30));

        text_date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                text_dateMouseClicked(evt);
            }
        });
        getContentPane().add(text_date, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 380, 140, 30));

        prodtbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item_ID", "Food Name", "Food Price", "Add date"
            }
        ));
        prodtbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                prodtblMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(prodtbl);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 210, 420, 420));

        jPanel4.setBackground(new java.awt.Color(153, 153, 153));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 340, 210));

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setForeground(new java.awt.Color(153, 153, 153));
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 640, 400, 50));

        imagebtn.setText("CHOOSE IMAGE");
        imagebtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        imagebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imagebtnActionPerformed(evt);
            }
        });
        getContentPane().add(imagebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 440, 180, 40));

        lblimg2.setBackground(new java.awt.Color(153, 153, 153));
        lblimg2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblimg2.setOpaque(true);
        getContentPane().add(lblimg2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 430, 200, 60));

        signout.setText("BACK");
        signout.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        signout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signoutActionPerformed(evt);
            }
        });
        getContentPane().add(signout, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 720, 180, 40));

        lblimg3.setBackground(new java.awt.Color(153, 153, 153));
        lblimg3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblimg3.setOpaque(true);
        getContentPane().add(lblimg3, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 710, 200, 60));

        jLabel5.setText("Restaurant Management System | © 2017-2018");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 860, -1, 20));

        signout1.setText("CLEAR");
        signout1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        signout1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signout1ActionPerformed(evt);
            }
        });
        getContentPane().add(signout1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 780, 210, 30));

        lblimg4.setBackground(new java.awt.Color(153, 153, 153));
        lblimg4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblimg4.setOpaque(true);
        getContentPane().add(lblimg4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 770, 230, 50));

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/For designing/admin.JPG"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 150, 170));

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel8.setText("Hello Admin:");

        getname.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        getname.setText("ADMIN");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(getname)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(getname, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, 240, 70));

        lblimg.setBackground(new java.awt.Color(153, 153, 153));
        lblimg.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblimg.setOpaque(true);
        getContentPane().add(lblimg, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, 340, 200));

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        addbtn.setText("ADD");
        addbtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        addbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addbtnActionPerformed(evt);
            }
        });

        updatebtn.setText("UPDATE");
        updatebtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebtnActionPerformed(evt);
            }
        });

        delbtn.setText("DELETE");
        delbtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        delbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(addbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(updatebtn, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(delbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updatebtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(delbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 710, 270, 50));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void text_priceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_text_priceActionPerformed

    }//GEN-LAST:event_text_priceActionPerformed

    private void imagebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imagebtnActionPerformed
        Database();
        JFileChooser file=new JFileChooser();
        file.setCurrentDirectory(new File(System.getProperty("user.home")));
        
        FileNameExtensionFilter filter=new FileNameExtensionFilter("*.image", "jpg", "png");
        file.addChoosableFileFilter(filter);
        int result=file.showSaveDialog(null);
        if(result==JFileChooser.APPROVE_OPTION){
            File selectedFile=file.getSelectedFile();
            String path=selectedFile.getAbsolutePath();
            lblimg.setIcon(ResizeImage(path, null));
            imgpath=path;
        }
        else{
            System.out.println("No File Selected");
        }
    }//GEN-LAST:event_imagebtnActionPerformed

    private void addbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addbtnActionPerformed
        if(checkInputs() && imgpath!=null){
            try {
                Database();
                PreparedStatement ps = con.prepareStatement("INSERT INTO foodsadmin(Name, Price, Add_date, Image)" + "values(?, ?, ?, ?) ");
                ps.setString(1, text_name.getText());
                ps.setString(2, text_price.getText());
                
                SimpleDateFormat df = new SimpleDateFormat("MM--dd--yyyy");
                String addDate = df.format((text_date.getDate()));
                ps.setString(3,addDate);
                
                InputStream img = new FileInputStream(new File(imgpath));
                ps.setBlob(4, img);
                ps.executeUpdate();
                
                showprodstbl();
                
                JOptionPane.showMessageDialog(null, "Data Inserted");
            } 
            catch (SQLException | FileNotFoundException | HeadlessException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }
        }
        else{
            JOptionPane.showMessageDialog(null, "One or more field are empty");
        }
        System.out.println("Name => " + text_name.getText());
        System.out.println("Price => " + text_price.getText());
        System.out.println("Image => " + imgpath);
    }//GEN-LAST:event_addbtnActionPerformed

    private void updatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebtnActionPerformed
        if(checkInputs() && text_id.getText()!=null){
            String updateQuery=null;
            PreparedStatement ps=null; 
            Database();
            
            //update w/o image
            if(imgpath == null){
                try{
                    updateQuery="UPDATE foodsadmin SET Name = ?, Price = ?" + ", Add_date = ? WHERE Id = ?";
                    ps=con.prepareStatement(updateQuery);
                    
                    ps.setString(1, text_name.getText());
                    ps.setString(2, text_price.getText());
                    
                    SimpleDateFormat df = new SimpleDateFormat("MM--dd--yyyy");
                    String addDate = df.format(text_date.getDate());
                    
                    ps.setString(3, addDate);
                    ps.setInt(4, Integer.parseInt(text_id.getText()));
                    
                    ps.executeUpdate();
                    showprodstbl();
                    JOptionPane.showMessageDialog(null, "Product Updated");
                }
                catch(SQLException ex){
                    Logger.getLogger(AdminWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            //update w/ image 
            else{
                try{
                    InputStream img = new FileInputStream (new File(imgpath));
                    updateQuery="UPDATE foodsadmin SET Name = ?, Price = ?" + ",Add_date = ?, Image = ? WHERE Id = ?";
                    ps = con.prepareStatement(updateQuery); 
                    
                    ps.setString(PROPERTIES, imgpath);
                   
                    ps.setString(1, text_name.getText());
                    ps.setString(2, text_price.getText());
                    
                    SimpleDateFormat df = new SimpleDateFormat("MM--dd--yyyy");
                    String addDate = df.format((text_date.getDate()));
                    
                    ps.setString(3, addDate);
                    ps.setBlob(4, img);
                    ps.setInt(5, Integer.parseInt(text_id.getText()));
                    
                    ps.executeUpdate();
                    showprodstbl();
                    JOptionPane.showMessageDialog(null, "Product Updated");
                }
                catch(FileNotFoundException | SQLException | NumberFormatException ex){
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        }
        else{
            JOptionPane.showMessageDialog(null, "One or more field(s) are empty or Wrong");
        }
    }//GEN-LAST:event_updatebtnActionPerformed

    private void delbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delbtnActionPerformed
        if(!text_id.getText().equals("")){
            try{
                Database();
                PreparedStatement ps = con.prepareStatement("DELETE FROM foodsadmin WHERE Id = ?");
                int id = Integer.parseInt(text_id.getText());
                ps.setInt(1, id);
                ps.executeUpdate();
                showprodstbl();
                JOptionPane.showMessageDialog(null, "Product Deleted!");
            } 
            catch (SQLException ex) {
                Logger.getLogger(AdminWindow.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Not Deleted!");
            }
        }
        else{
            JOptionPane.showMessageDialog(null, "Product Not Deleted : No id to delete found!");
        }
    }//GEN-LAST:event_delbtnActionPerformed

    private void prodtblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_prodtblMouseClicked
        int index=prodtbl.getSelectedRow();
        showItems(index);
    }//GEN-LAST:event_prodtblMouseClicked

    private void firstbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstbtnActionPerformed
        Database();
        pos = 0; 
        showItems(pos); 
    }//GEN-LAST:event_firstbtnActionPerformed

    private void lastbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lastbtnActionPerformed
        Database();
        pos = getProductList().size()-1;
        showItems(pos); 
    }//GEN-LAST:event_lastbtnActionPerformed

    private void prevbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prevbtnActionPerformed
        Database();
        pos++;
        if(pos>=getProductList().size()){
            pos=getProductList().size()-1;
            showItems(pos);
        }
    }//GEN-LAST:event_prevbtnActionPerformed

    private void nextbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextbtnActionPerformed
        Database();
        pos--;
        if(pos < 0){
            pos=0;
        }
        showItems(pos);
    }//GEN-LAST:event_nextbtnActionPerformed

    private void text_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_text_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_text_idActionPerformed

    private void signoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signoutActionPerformed
        Home hm = new Home();
        hm.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_signoutActionPerformed

    private void signout1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signout1ActionPerformed
        text_id.setText(""); 
        text_name.setText("");
        text_price.setText("");
        text_date.setCalendar(null);
        lblimg.setIcon(null);
    }//GEN-LAST:event_signout1ActionPerformed

    private void text_dateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_text_dateMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_text_dateMouseClicked
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addbtn;
    private javax.swing.JButton delbtn;
    private javax.swing.JButton firstbtn;
    private javax.swing.JLabel getname;
    private javax.swing.JButton imagebtn;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton lastbtn;
    private javax.swing.JLabel lblimg;
    private javax.swing.JLabel lblimg2;
    private javax.swing.JLabel lblimg3;
    private javax.swing.JLabel lblimg4;
    private javax.swing.JButton nextbtn;
    private javax.swing.JButton prevbtn;
    private javax.swing.JTable prodtbl;
    private javax.swing.JButton signout;
    private javax.swing.JButton signout1;
    private com.toedter.calendar.JDateChooser text_date;
    private javax.swing.JTextField text_id;
    private javax.swing.JTextField text_name;
    private javax.swing.JTextField text_price;
    private javax.swing.JButton updatebtn;
    // End of variables declaration//GEN-END:variables
}