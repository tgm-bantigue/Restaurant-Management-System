package restopack;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Connection {
    public static Statement s;
    public static Statement ss;
    public static java.sql.Connection con;

    public Connection(){
        try {
          
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rmdb", "root","");
            System.out.println("Connected to database!");
        } catch (SQLException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public static void main(String[] args) {
        Connection c = new Connection(); 
    }
}